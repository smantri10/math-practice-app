// OpenAI Question Generator

class OpenAIGenerator {
    constructor() {
        this.apiKey = localStorage.getItem('openai_api_key') || '';
        this.apiEndpoint = 'https://api.openai.com/v1/chat/completions';
        this.totalCost = parseFloat(localStorage.getItem('openai_total_cost') || '0');
    }

    hasApiKey() {
        return this.apiKey && this.apiKey.length > 0;
    }

    saveApiKey(key) {
        localStorage.setItem('openai_api_key', key);
        this.apiKey = key;
    }

    getTotalCost() {
        return this.totalCost;
    }

    async testApiKey(apiKey) {
        const response = await fetch(this.apiEndpoint, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'gpt-4o-mini',
                messages: [{
                    role: 'user',
                    content: 'Reply with only: "API working"'
                }],
                max_tokens: 10
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error?.message || 'Invalid API key');
        }

        return true;
    }

    async generateQuestions(grade, count = 30) {
        if (!this.hasApiKey()) {
            throw new Error('API key not configured');
        }

        const prompt = this.createPrompt(grade, count);

        const response = await fetch(this.apiEndpoint, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'gpt-4o-mini',
                messages: [
                    {
                        role: 'system',
                        content: 'You are an expert math competition question generator specializing in Math Olympiad, Kangaroo Math, and AMC style problems. Always return valid JSON only, no markdown formatting.'
                    },
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                temperature: 0.9,
                max_tokens: 8000
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error?.message || 'API request failed');
        }

        const data = await response.json();
        
        // Calculate and track cost
        const inputTokens = data.usage.prompt_tokens;
        const outputTokens = data.usage.completion_tokens;
        const cost = (inputTokens / 1000000 * 0.15) + (outputTokens / 1000000 * 0.60);
        this.totalCost += cost;
        localStorage.setItem('openai_total_cost', this.totalCost.toString());

        const generatedText = data.choices[0].message.content;
        return this.parseQuestions(generatedText, grade);
    }

    createPrompt(grade, count) {
        return `Generate exactly ${count} unique math competition questions for Grade ${grade} students.

Requirements:
- Match the style and difficulty of Math Olympiad, Kangaroo Math, and AMC competitions
- Mix of topics: ${this.getGradeTopics(grade)}
- Difficulty distribution: 
  * Questions 1-8: easy (warm-up)
  * Questions 9-16: medium (core practice)
  * Questions 17-24: hard (challenging)
  * Questions 25-30: challenging (advanced)
- Progressive difficulty: Each question should be slightly harder than the previous
- Each question must have a clear numerical or short text answer
- Provide 3 progressive hints per question
- Include detailed step-by-step solution

Return ONLY a JSON array (no markdown, no code blocks):
[
  {
    "difficulty": "easy|medium|hard|challenging",
    "question": "Question text here",
    "answer": "Exact answer (number or short text)",
    "hints": [
      "Hint 1: General approach",
      "Hint 2: Key steps", 
      "Hint 3: Nearly complete solution"
    ],
    "solution": "Complete step-by-step explanation"
  }
]

IMPORTANT: Order questions from easiest to hardest. Start simple and progressively increase complexity.

Generate ${count} questions now:`;
    }

    getGradeTopics(grade) {
        const topics = {
            4: 'arithmetic, basic geometry (perimeter/area), patterns, fractions, simple word problems',
            5: 'fractions/decimals/percentages, area/perimeter, primes/factors, ratios, multi-step problems',
            6: 'integers, ratios/proportions, basic algebra, angles/triangles/circles, probability',
            7: 'linear equations, Pythagorean theorem, probability/statistics, exponents/roots, word problems',
            8: 'quadratic equations, coordinate geometry, systems of equations, functions, combinatorics'
        };
        return topics[grade] || topics[6];
    }

    parseQuestions(jsonText, grade) {
        try {
            // Remove markdown code blocks if present
            let cleanJson = jsonText.trim();
            cleanJson = cleanJson.replace(/```json\n?/g, '');
            cleanJson = cleanJson.replace(/```\n?/g, '');
            cleanJson = cleanJson.trim();

            const questions = JSON.parse(cleanJson);
            
            if (!Array.isArray(questions)) {
                throw new Error('Response is not an array');
            }

            // Validate and format questions
            return questions.map((q, index) => ({
                id: index + 1,
                difficulty: q.difficulty || 'medium',
                question: q.question,
                answer: String(q.answer),
                hints: Array.isArray(q.hints) ? q.hints : [],
                solution: q.solution || 'No solution provided',
                source: 'AI Generated (OpenAI)',
                grade: grade
            }));
        } catch (error) {
            console.error('Parse error:', error);
            console.log('Raw response:', jsonText);
            throw new Error('Failed to parse AI response. Please try again.');
        }
    }
}

// Global instance
const openAIGenerator = new OpenAIGenerator();
