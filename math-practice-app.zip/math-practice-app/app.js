// Math Practice App - Main Application Logic

// Application State
let state = {
    currentGrade: null,
    questions: [],
    currentQuestionIndex: 0,
    answers: [],
    startTime: null,
    questionStartTime: null,
    hintsRevealed: 0,
    performanceData: {
        correctCount: 0,
        totalTime: 0,
        questionTimes: [],
        difficultyProgression: []
    }
};

// DOM Elements - will be initialized after DOM loads
let screens = {};

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    // Initialize screen references
    screens = {
        welcome: document.getElementById('welcome-screen'),
        practice: document.getElementById('practice-screen'),
        results: document.getElementById('results-screen'),
        review: document.getElementById('review-screen'),
        loading: document.getElementById('loading-screen')
    };
    
    initializeEventListeners();
    updateModeIndicator();
    loadProgress();
});

function initializeEventListeners() {
    // OpenAI API key setup
    const saveApiKeyBtn = document.getElementById('save-api-key');
    if (saveApiKeyBtn) {
        saveApiKeyBtn.addEventListener('click', () => {
            const apiKey = document.getElementById('api-key-input').value.trim();
            const statusDiv = document.getElementById('api-status');
            
            if (!apiKey) {
                statusDiv.innerHTML = '<span style="color: #e74c3c;">⚠️ Please enter an API key</span>';
                return;
            }
            
            if (!apiKey.startsWith('sk-')) {
                statusDiv.innerHTML = '<span style="color: #e74c3c;">⚠️ Invalid API key format</span>';
                return;
            }
            
            openAIGenerator.saveApiKey(apiKey);
            statusDiv.innerHTML = '<span style="color: #27ae60;">✅ API key saved! AI mode enabled.</span>';
            updateModeIndicator();
            
            // Clear input for security
            document.getElementById('api-key-input').value = '';
        });
    }
    
    // Grade selection
    document.querySelectorAll('.grade-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const grade = e.target.dataset.grade;
            startPractice(grade);
        });
    });
    
    // Navigation
    document.getElementById('back-btn').addEventListener('click', () => {
        if (confirm('Are you sure you want to quit? Your progress will be lost.')) {
            showScreen('welcome');
            resetState();
        }
    });
    
    document.getElementById('submit-btn').addEventListener('click', submitAnswer);
    document.getElementById('hint-btn').addEventListener('click', revealHint);
    document.getElementById('prev-btn').addEventListener('click', previousQuestion);
    document.getElementById('next-btn').addEventListener('click', nextQuestion);
    document.getElementById('review-btn').addEventListener('click', showReview);
    document.getElementById('new-practice-btn').addEventListener('click', () => {
        if (state.currentGrade) {
            // Generate new questions for same grade
            startPractice(state.currentGrade);
        } else {
            showScreen('welcome');
            resetState();
        }
    });
    document.getElementById('change-grade-btn').addEventListener('click', () => {
        showScreen('welcome');
        resetState();
    });
    document.getElementById('back-to-results-btn').addEventListener('click', () => {
        showScreen('results');
    });
    
    // Enter key to submit answer
    document.getElementById('answer-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            submitAnswer();
        }
    });
}

async function startPractice(grade) {
    state.currentGrade = grade;
    
    // Try AI generation if API key exists
    if (openAIGenerator.hasApiKey()) {
        try {
            showScreen('loading');
            document.getElementById('loading-grade').textContent = grade;
            
            const aiQuestions = await openAIGenerator.generateQuestions(grade, 30);
            state.questions = aiQuestions;
            
        } catch (error) {
            console.error('AI generation failed:', error);
            alert('⚠️ AI generation failed. Using offline questions.\n\nError: ' + error.message);
            state.questions = generateDailyQuestions(grade);
        }
    } else {
        // Use offline questions
        state.questions = generateDailyQuestions(grade);
    }
    
    state.currentQuestionIndex = 0;
    state.answers = [];
    state.startTime = Date.now();
    state.performanceData = {
        correctCount: 0,
        totalTime: 0,
        questionTimes: [],
        difficultyProgression: []
    };
    
    showScreen('practice');
    loadQuestion();
}

function loadQuestion() {
    if (state.currentQuestionIndex >= state.questions.length) {
        endPractice();
        return;
    }
    
    const question = state.questions[state.currentQuestionIndex];
    state.questionStartTime = Date.now();
    state.hintsRevealed = 0;
    
    // Update UI
    document.getElementById('question-counter').textContent = 
        `Question ${state.currentQuestionIndex + 1}/30`;
    document.getElementById('question-text').textContent = question.question;
    
    // Restore previous answer if exists
    const previousAnswer = state.answers[state.currentQuestionIndex];
    if (previousAnswer) {
        document.getElementById('answer-input').value = previousAnswer.userAnswer;
        
        // Show feedback for previously answered questions
        const feedback = document.getElementById('feedback');
        if (previousAnswer.isCorrect) {
            feedback.className = 'feedback correct';
            feedback.innerHTML = '✓ Correct! Great job!';
        } else {
            feedback.className = 'feedback incorrect';
            feedback.innerHTML = `
                ✗ Not quite right. The answer is: ${previousAnswer.correctAnswer}<br>
                <small>${previousAnswer.solution}</small>
            `;
        }
    } else {
        document.getElementById('answer-input').value = '';
        document.getElementById('feedback').innerHTML = '';
        document.getElementById('feedback').className = 'feedback';
    }
    
    document.getElementById('hints-display').innerHTML = '';
    
    // Set difficulty badge
    const difficultyBadge = document.getElementById('difficulty-level');
    difficultyBadge.textContent = question.difficulty.charAt(0).toUpperCase() + 
                                   question.difficulty.slice(1);
    difficultyBadge.className = question.difficulty;
    
    // Enable input and buttons
    document.getElementById('answer-input').disabled = false;
    document.getElementById('submit-btn').disabled = false;
    document.getElementById('hint-btn').disabled = false;
    document.getElementById('answer-input').focus();
    
    // Update navigation buttons
    updateNavigationButtons();
}

function updateNavigationButtons() {
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    
    // Disable previous button on first question
    prevBtn.disabled = state.currentQuestionIndex === 0;
    
    // Update next button text and state
    if (state.currentQuestionIndex === state.questions.length - 1) {
        nextBtn.textContent = 'Finish →';
    } else {
        nextBtn.textContent = 'Next →';
    }
}

function previousQuestion() {
    if (state.currentQuestionIndex > 0) {
        state.currentQuestionIndex--;
        loadQuestion();
    }
}

function nextQuestion() {
    // Save current answer if provided
    const userAnswer = document.getElementById('answer-input').value.trim();
    if (userAnswer && state.currentQuestionIndex >= state.answers.length) {
        saveCurrentAnswer();
    }
    
    // Move to next question or finish
    if (state.currentQuestionIndex < state.questions.length - 1) {
        state.currentQuestionIndex++;
        loadQuestion();
    } else {
        endPractice();
    }
}

function saveCurrentAnswer() {
    const userAnswer = document.getElementById('answer-input').value.trim();
    const question = state.questions[state.currentQuestionIndex];
    const timeSpent = state.questionStartTime ? (Date.now() - state.questionStartTime) / 1000 : 0;
    const isCorrect = checkAnswer(userAnswer, question.answer);
    
    state.answers[state.currentQuestionIndex] = {
        question: question.question,
        userAnswer: userAnswer,
        correctAnswer: question.answer,
        isCorrect: isCorrect,
        timeSpent: timeSpent,
        hintsUsed: state.hintsRevealed,
        difficulty: question.difficulty,
        solution: question.solution
    };
    
    if (isCorrect) {
        state.performanceData.correctCount++;
    }
    
    state.performanceData.questionTimes.push(timeSpent);
    state.performanceData.difficultyProgression.push({
        questionNum: state.currentQuestionIndex + 1,
        difficulty: question.difficulty,
        correct: isCorrect
    });
}

function revealHint() {
    const question = state.questions[state.currentQuestionIndex];
    
    if (state.hintsRevealed >= question.hints.length) {
        alert('No more hints available!');
        return;
    }
    
    const hintsDisplay = document.getElementById('hints-display');
    const hintDiv = document.createElement('div');
    hintDiv.className = 'hint-item';
    hintDiv.textContent = `Hint ${state.hintsRevealed + 1}: ${question.hints[state.hintsRevealed]}`;
    hintsDisplay.appendChild(hintDiv);
    
    state.hintsRevealed++;
}

function submitAnswer() {
    const userAnswer = document.getElementById('answer-input').value.trim();
    
    if (!userAnswer) {
        alert('Please enter an answer!');
        return;
    }
    
    const question = state.questions[state.currentQuestionIndex];
    const timeSpent = (Date.now() - state.questionStartTime) / 1000; // in seconds
    
    // Check answer (flexible matching)
    const isCorrect = checkAnswer(userAnswer, question.answer);
    
    // Record answer
    state.answers.push({
        question: question.question,
        userAnswer: userAnswer,
        correctAnswer: question.answer,
        isCorrect: isCorrect,
        timeSpent: timeSpent,
        hintsUsed: state.hintsRevealed,
        difficulty: question.difficulty,
        solution: question.solution
    });
    
    // Update performance data
    state.performanceData.questionTimes.push(timeSpent);
    state.performanceData.difficultyProgression.push({
        questionNum: state.currentQuestionIndex + 1,
        difficulty: question.difficulty,
        correct: isCorrect
    });
    
    if (isCorrect) {
        state.performanceData.correctCount++;
    }
    
    // Show feedback
    const feedback = document.getElementById('feedback');
    if (isCorrect) {
        feedback.className = 'feedback correct';
        feedback.innerHTML = '✓ Correct! Great job!';
    } else {
        feedback.className = 'feedback incorrect';
        feedback.innerHTML = `
            ✗ Not quite right. The answer is: ${question.answer}<br>
            <small>${question.solution}</small>
        `;
    }
    
    // Adaptive difficulty adjustment
    adjustDifficulty(isCorrect, timeSpent);
}

function checkAnswer(userAnswer, correctAnswer) {
    // Normalize answers for comparison
    const normalize = (str) => {
        return str.toString()
            .toLowerCase()
            .replace(/\s+/g, '')
            .replace(/,/g, '')
            .replace(/\$/g, '')
            .replace(/cm²/g, '')
            .replace(/m²/g, '')
            .replace(/meters?/g, '')
            .replace(/hours?/g, '')
            .replace(/minutes?/g, '');
    };
    
    const normalizedUser = normalize(userAnswer);
    const normalizedCorrect = normalize(correctAnswer);
    
    // Direct match
    if (normalizedUser === normalizedCorrect) return true;
    
    // Check if it's a numerical answer with tolerance
    const userNum = parseFloat(normalizedUser);
    const correctNum = parseFloat(normalizedCorrect);
    
    if (!isNaN(userNum) && !isNaN(correctNum)) {
        return Math.abs(userNum - correctNum) < 0.01;
    }
    
    // Check for multiple acceptable formats (e.g., "2 and 3" vs "2, 3" vs "x=2 or x=3")
    if (normalizedCorrect.includes('or') || normalizedCorrect.includes('and')) {
        return normalizedUser.includes(normalizedCorrect) || 
               normalizedCorrect.includes(normalizedUser);
    }
    
    return false;
}

function adjustDifficulty(isCorrect, timeSpent) {
    // Adaptive difficulty: adjust upcoming questions based on performance
    const avgTime = state.performanceData.questionTimes.reduce((a, b) => a + b, 0) / 
                    state.performanceData.questionTimes.length;
    
    const recentCorrect = state.answers.slice(-5).filter(a => a.isCorrect).length;
    const recentAccuracy = state.answers.length >= 5 ? recentCorrect / 5 : 
                          state.performanceData.correctCount / state.answers.length;
    
    // Enhanced progressive difficulty system
    if (isCorrect) {
        // Every correct answer increases difficulty
        if (timeSpent < avgTime * 1.2 || state.hintsRevealed === 0) {
            // Answered quickly or without hints - significantly increase difficulty
            increaseDifficulty();
        } else if (recentAccuracy >= 0.6) {
            // Moderate performance - moderate increase
            increaseDifficulty();
        }
    } else {
        // Wrong answer - only decrease if struggling badly
        if (recentAccuracy < 0.4 || state.hintsRevealed >= 2) {
            decreaseDifficulty();
        }
    }
}

function increaseDifficulty() {
    // Reorder remaining questions to prioritize harder ones
    const remaining = state.questions.slice(state.currentQuestionIndex + 1);
    const difficultyOrder = { 'easy': 1, 'medium': 2, 'hard': 3, 'challenging': 4 };
    
    remaining.sort((a, b) => difficultyOrder[b.difficulty] - difficultyOrder[a.difficulty]);
    
    // Replace remaining questions
    state.questions.splice(state.currentQuestionIndex + 1, remaining.length, ...remaining);
}

function decreaseDifficulty() {
    // Reorder remaining questions to prioritize easier ones
    const remaining = state.questions.slice(state.currentQuestionIndex + 1);
    const difficultyOrder = { 'easy': 1, 'medium': 2, 'hard': 3, 'challenging': 4 };
    
    remaining.sort((a, b) => difficultyOrder[a.difficulty] - difficultyOrder[b.difficulty]);
    
    // Replace remaining questions
    state.questions.splice(state.currentQuestionIndex + 1, remaining.length, ...remaining);
}

function endPractice() {
    state.performanceData.totalTime = (Date.now() - state.startTime) / 1000;
    showResults();
}

function showResults() {
    showScreen('results');
    
    const totalQuestions = state.answers.length;
    const correctCount = state.performanceData.correctCount;
    const accuracy = ((correctCount / totalQuestions) * 100).toFixed(1);
    const totalTime = state.performanceData.totalTime;
    const avgTime = (totalTime / totalQuestions).toFixed(1);
    
    // Update stats
    document.getElementById('total-solved').textContent = `${correctCount}/${totalQuestions}`;
    document.getElementById('accuracy-rate').textContent = `${accuracy}%`;
    document.getElementById('total-time').textContent = formatTime(totalTime);
    document.getElementById('avg-time').textContent = `${avgTime}s`;
    
    // Draw performance chart
    drawPerformanceChart();
    
    // Show difficulty trend
    showDifficultyTrend();
    
    // Save progress
    saveProgress();
}

function drawPerformanceChart() {
    const canvas = document.getElementById('performance-canvas');
    const ctx = canvas.getContext('2d');
    
    // Set canvas size
    canvas.width = canvas.offsetWidth;
    canvas.height = 200;
    
    const width = canvas.width;
    const height = canvas.height;
    const padding = 40;
    
    // Clear canvas
    ctx.clearRect(0, 0, width, height);
    
    // Calculate running accuracy
    const runningAccuracy = [];
    let correctSoFar = 0;
    
    state.answers.forEach((answer, index) => {
        if (answer.isCorrect) correctSoFar++;
        runningAccuracy.push((correctSoFar / (index + 1)) * 100);
    });
    
    // Draw axes
    ctx.strokeStyle = '#ccc';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, height - padding);
    ctx.lineTo(width - padding, height - padding);
    ctx.stroke();
    
    // Draw labels
    ctx.fillStyle = '#666';
    ctx.font = '12px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Questions', width / 2, height - 10);
    
    ctx.save();
    ctx.translate(15, height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText('Accuracy %', 0, 0);
    ctx.restore();
    
    // Draw line graph
    ctx.strokeStyle = '#667eea';
    ctx.lineWidth = 3;
    ctx.beginPath();
    
    runningAccuracy.forEach((acc, index) => {
        const x = padding + (index / (runningAccuracy.length - 1)) * (width - 2 * padding);
        const y = height - padding - (acc / 100) * (height - 2 * padding);
        
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    
    ctx.stroke();
    
    // Draw points
    runningAccuracy.forEach((acc, index) => {
        const x = padding + (index / (runningAccuracy.length - 1)) * (width - 2 * padding);
        const y = height - padding - (acc / 100) * (height - 2 * padding);
        
        ctx.fillStyle = state.answers[index].isCorrect ? '#28a745' : '#dc3545';
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, 2 * Math.PI);
        ctx.fill();
    });
}

function showDifficultyTrend() {
    const trendDiv = document.getElementById('difficulty-trend');
    const difficultyCount = { easy: 0, medium: 0, hard: 0, challenging: 0 };
    const difficultyCorrect = { easy: 0, medium: 0, hard: 0, challenging: 0 };
    
    state.answers.forEach(answer => {
        difficultyCount[answer.difficulty]++;
        if (answer.isCorrect) {
            difficultyCorrect[answer.difficulty]++;
        }
    });
    
    let trendHTML = '';
    Object.keys(difficultyCount).forEach(level => {
        if (difficultyCount[level] > 0) {
            const accuracy = ((difficultyCorrect[level] / difficultyCount[level]) * 100).toFixed(0);
            trendHTML += `
                <div class="trend-item">
                    <strong>${level.charAt(0).toUpperCase() + level.slice(1)}:</strong> 
                    ${difficultyCorrect[level]}/${difficultyCount[level]} correct (${accuracy}%)
                </div>
            `;
        }
    });
    
    // Overall trend analysis
    const startAccuracy = state.answers.slice(0, 10).filter(a => a.isCorrect).length / 10 * 100;
    const endAccuracy = state.answers.slice(-10).filter(a => a.isCorrect).length / 10 * 100;
    const trend = endAccuracy > startAccuracy ? 'improving' : 
                  endAccuracy < startAccuracy ? 'declining' : 'steady';
    
    trendHTML += `
        <div class="trend-item" style="margin-top: 15px; border-left-color: #764ba2;">
            <strong>Overall Trend:</strong> Your performance is ${trend}! 
            ${trend === 'improving' ? '🎉 Keep it up!' : 
              trend === 'declining' ? '💪 You can do better!' : 
              '👍 Consistent work!'}
        </div>
    `;
    
    trendDiv.innerHTML = trendHTML;
}

function showReview() {
    showScreen('review');
    
    const reviewContainer = document.getElementById('review-container');
    reviewContainer.innerHTML = '';
    
    state.answers.forEach((answer, index) => {
        const reviewItem = document.createElement('div');
        reviewItem.className = `review-item ${answer.isCorrect ? 'correct' : 'incorrect'}`;
        
        reviewItem.innerHTML = `
            <div class="review-question">
                <strong>Question ${index + 1}:</strong> ${answer.question}
            </div>
            <div class="review-answer">
                <div>
                    <strong>Your answer:</strong> ${answer.userAnswer}
                </div>
                <div>
                    <strong>${answer.isCorrect ? '✓ Correct' : '✗ Incorrect'}</strong>
                </div>
            </div>
            ${!answer.isCorrect ? `
                <div class="review-answer">
                    <div><strong>Correct answer:</strong> ${answer.correctAnswer}</div>
                </div>
            ` : ''}
            <div class="review-solution">
                <h4>Solution:</h4>
                <p>${answer.solution}</p>
            </div>
            <div style="margin-top: 10px; color: #666; font-size: 0.9em;">
                ⏱️ Time: ${answer.timeSpent.toFixed(1)}s | 
                💡 Hints used: ${answer.hintsUsed} | 
                Difficulty: ${answer.difficulty}
            </div>
        `;
        
        reviewContainer.appendChild(reviewItem);
    });
}

function showScreen(screenName) {
    Object.values(screens).forEach(screen => screen.classList.remove('active'));
    screens[screenName].classList.add('active');
}

function updateModeIndicator() {
    const indicator = document.getElementById('mode-indicator');
    if (indicator) {
        if (openAIGenerator.hasApiKey()) {
            indicator.innerHTML = '🤖 Mode: AI-Powered Questions (Cost: $' + openAIGenerator.getTotalCost().toFixed(4) + ')';
            indicator.style.background = '#d4edda';
            indicator.style.color = '#155724';
        } else {
            indicator.innerHTML = '📚 Mode: Offline Questions';
            indicator.style.background = '#e7f3ff';
            indicator.style.color = '#2196F3';
        }
    }
}

function resetState() {
    state = {
        currentGrade: null,
        questions: [],
        currentQuestionIndex: 0,
        answers: [],
        startTime: null,
        questionStartTime: null,
        hintsRevealed: 0,
        performanceData: {
            correctCount: 0,
            totalTime: 0,
            questionTimes: [],
            difficultyProgression: []
        }
    };
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function saveProgress() {
    const progress = {
        date: new Date().toISOString(),
        grade: state.currentGrade,
        accuracy: (state.performanceData.correctCount / state.answers.length * 100).toFixed(1),
        totalQuestions: state.answers.length,
        correctAnswers: state.performanceData.correctCount
    };
    
    // Save to localStorage
    const history = JSON.parse(localStorage.getItem('mathPracticeHistory') || '[]');
    history.push(progress);
    localStorage.setItem('mathPracticeHistory', JSON.stringify(history));
}

function loadProgress() {
    // Could be used to show historical performance on welcome screen
    const history = JSON.parse(localStorage.getItem('mathPracticeHistory') || '[]');
    console.log('Practice history:', history);
}
