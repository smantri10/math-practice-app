# Math Champion - Competition Practice App

A web-based math practice application for students in grades 4-8 preparing for international math competitions (Math Olympiad, Kangaroo, AMC, etc.).

## Features

### Core Features
- **AI-Powered Questions** (Optional): Generate unlimited unique questions using OpenAI GPT-4o-mini
- **Offline Question Bank**: Works without internet with pre-built question variations
- **4 Grade Levels**: Customized difficulty for grades 4-8
- **30 Questions Per Session**: Competition-style practice sets
- **Progressive Hints**: 3-level hint system for each question
- **Navigation**: Previous/Next buttons to review and change answers
- **Adaptive Difficulty**: Questions adjust based on performance
- **Progress Tracking**: Visual charts showing accuracy, time, and difficulty trends
- **Detailed Review**: Step-by-step solutions for every question

### AI Integration (Optional)
- **Cost**: ~$0.02-0.03 per 30-question session (~$1-2/month for daily practice)
- **Quality**: Fresh, unique competition-style questions every session
- **Setup**: One-time API key configuration (2 minutes)
- **Fallback**: Automatically uses offline questions if AI fails

## Quick Start

### Option 1: Offline Mode (100% Free)
1. Open `index.html` in any modern web browser
2. Select your grade
3. Start practicing with 30 unique questions

### Option 2: AI Mode (~$1-2/month)
1. Open `index.html` in a web browser
2. Click "⚙️ Setup OpenAI" on the welcome screen
3. Follow the 4-step setup guide:
   - Visit [OpenAI API Keys](https://platform.openai.com/api-keys)
   - Add $5-10 credit (lasts months)
   - Create a new API key
   - Paste it in the app and click "Save"
4. Select your grade and get AI-generated questions!

## Technical Details

### Technologies
- **Frontend**: Pure HTML5, CSS3, JavaScript (no frameworks)
- **AI API**: OpenAI GPT-4o-mini
- **Storage**: localStorage (API keys, cost tracking)
- **Compatibility**: Works on all modern browsers (Chrome, Firefox, Safari, Edge)

### Question Generation
- **Offline Mode**: 9 base questions per grade with 4+ parametric variations each
- **AI Mode**: OpenAI generates 30 unique questions based on:
  - Grade level (4-8)
  - Competition types (Olympiad, Kangaroo, AMC)
  - Difficulty balance (25% easy, 50% medium, 25% hard)
  - Topic coverage (arithmetic, algebra, geometry, logic, number theory)

### Cost Breakdown (AI Mode)
- **Model**: GPT-4o-mini
- **Pricing**: $0.15/1M input tokens, $0.60/1M output tokens
- **Per Session**: ~1,500 input + 3,000 output tokens = $0.02-0.03
- **Monthly**: ~$1-2 for daily practice (30 days × $0.025)

### File Structure
```
math-practice-app/
├── index.html              # Main app structure
├── styles.css              # UI styling (kid-friendly purple theme)
├── questions.js            # Offline question bank
├── openai-generator.js     # OpenAI API integration
├── app.js                  # Core application logic
├── README.md               # This file
└── SETUP-GUIDE.md         # User-friendly setup instructions
```

## Privacy & Security
- API keys stored locally in browser (localStorage)
- No data sent to external servers (except OpenAI for question generation)
- No user accounts or sign-ups required
- Works completely offline when not using AI mode

## Browser Compatibility
- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

## Development

### Running Locally
```bash
# Using Python 3
python -m http.server 8080

# Using Node.js
npx http-server -p 8080

# Then open http://localhost:8080
```

### Customization
- **Questions**: Edit `questions.js` to add more offline questions
- **Styling**: Modify `styles.css` for different themes
- **Grade Levels**: Extend `questions.js` and `app.js` for more grades
- **AI Prompts**: Customize prompts in `openai-generator.js`

## Support

### Common Issues

**AI questions not generating?**
- Check internet connection
- Verify API key is correct (test it with the "Test" button)
- Ensure OpenAI account has credit
- App will automatically fall back to offline questions

**Questions too easy/hard?**
- Adaptive difficulty adjusts over time
- Try starting with correct grade level
- AI mode provides better difficulty balance

**App not loading?**
- Use a modern browser (Chrome, Firefox, Safari)
- Check browser console for errors (F12)
- Try opening in incognito/private mode

## License
Free to use for educational purposes.

## Credits
Designed for students preparing for international math competitions like Math Olympiad, Math Kangaroo, AMC 8/10, and similar contests.
